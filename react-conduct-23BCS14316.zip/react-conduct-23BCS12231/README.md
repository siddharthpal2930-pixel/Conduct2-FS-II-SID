# Redux Toolkit To-Do

Minimal React + Redux Toolkit To-Do example.

Setup

```bash
npm install
npm run dev
```

Files of interest

- Store: [src/store.js](src/store.js)
- Slice: [src/features/todo/todoSlice.js](src/features/todo/todoSlice.js)
- Main UI: [src/features/todo/TodoApp.jsx](src/features/todo/TodoApp.jsx)

Usage

- Type a task title and click Add (default status: "Pending").
- Click "Mark Done" / "Mark Pending" to toggle status.
- Click "Delete" to remove a task.
