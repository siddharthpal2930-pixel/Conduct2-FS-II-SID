import React, { useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { addTask, toggleStatus, deleteTask } from './todoSlice'
import TaskItem from './TaskItem'

export default function TodoApp() {
  const tasks = useSelector((state) => state.todo.tasks)
  const dispatch = useDispatch()
  const [title, setTitle] = useState('')

  const onAdd = () => {
    const trimmed = title.trim()
    if (!trimmed) return
    dispatch(addTask(trimmed))
    setTitle('')
  }

  return (
    <div className="todo-container">
      <h1>Redux Toolkit To-Do</h1>
      <div className="input-row">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter new task"
          onKeyDown={(e) => e.key === 'Enter' && onAdd()}
        />
        <button onClick={onAdd}>Add</button>
      </div>

      <ul className="task-list">
        {tasks.length === 0 && <li className="empty">No tasks yet</li>}
        {tasks.map((t, i) => (
          <TaskItem
            key={i}
            index={i}
            title={t.title}
            status={t.status}
            onToggle={() => dispatch(toggleStatus(i))}
            onDelete={() => dispatch(deleteTask(i))}
          />
        ))}
      </ul>
    </div>
  )
}
