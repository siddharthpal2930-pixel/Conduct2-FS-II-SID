import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  tasks: [],
}

const todoSlice = createSlice({
  name: 'todo',
  initialState,
  reducers: {
    addTask: (state, action) => {
      state.tasks.push({ title: action.payload, status: 'Pending' })
    },
    toggleStatus: (state, action) => {
      const index = action.payload
      const task = state.tasks[index]
      if (task) {
        task.status = task.status === 'Pending' ? 'Done' : 'Pending'
      }
    },
    deleteTask: (state, action) => {
      const index = action.payload
      if (index >= 0 && index < state.tasks.length) {
        state.tasks.splice(index, 1)
      }
    },
  },
})

export const { addTask, toggleStatus, deleteTask } = todoSlice.actions
export default todoSlice.reducer
