import React from 'react'

export default function TaskItem({ index, title, status, onToggle, onDelete }) {
  return (
    <li className="task-item">
      <span className="task-title">{title}</span>
      <span className={`task-status ${status === 'Done' ? 'done' : ''}`}>{status}</span>
      <div className="task-actions">
        <button onClick={onToggle}>{status === 'Pending' ? 'Mark Done' : 'Mark Pending'}</button>
        <button className="delete" onClick={onDelete}>Delete</button>
      </div>
    </li>
  )
}
