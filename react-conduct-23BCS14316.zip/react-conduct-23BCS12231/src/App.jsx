import React from 'react'
import TodoApp from './features/todo/TodoApp'

export default function App() {
  return (
    <div className="app">
      <TodoApp />
    </div>
  )
}
